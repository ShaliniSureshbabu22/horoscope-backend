require 'coveralls'
Coveralls.wear!
require 'horoscope'
